<!-- preloader css -->
<!-- selectr css -->
<link href="assets/libs/mobius1-selectr/selectr.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="assets/css/preloader.min.css" type="text/css" />
<script src="assets/libs/jquery/jquery.min.js"></script>
<!-- choices css -->
<link href="assets/libs/choices.js/public/assets/styles/choices.min.css" rel="stylesheet" type="text/css" />

<!-- alertifyjs Css -->
<link href="assets/libs/alertifyjs/build/css/alertify.min.css" rel="stylesheet" type="text/css" />

<!-- alertifyjs default themes  Css -->
<link href="assets/libs/alertifyjs/build/css/themes/default.min.css" rel="stylesheet" type="text/css" />

<!-- Bootstrap Css -->
<link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
<script src="assets/libs/jquery/jquery.min.js"></script>

<!-- apexcharts -->
<script src="assets/libs/apexcharts/apexcharts.min.js"></script>