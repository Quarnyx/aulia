<?php include 'layouts/session.php'; ?>
<?php include 'layouts/head-main.php'; ?>

<head>
    <title>Blog Details | Minia - Admin & Dashboard Template</title>
    <?php include 'layouts/head.php'; ?>
    <?php include 'layouts/head-style.php'; ?>
</head>

<?php include 'layouts/body.php'; ?>

        <!-- Begin page -->
        <div id="layout-wrapper">

        <?php include 'layouts/menu.php'; ?>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Blog Details</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Blog</a></li>
                                            <li class="breadcrumb-item active">Blog Details</li>
                                        </ol>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="">
                                            <div class="text-center mb-3">
                                                <h4>Beautiful Day with Friends</h4>
                                            </div>
                                            <div class="mb-4">
                                                <img src="assets/images/small/img-2.jpg" alt="" class="img-thumbnail mx-auto d-block">
                                            </div>

                                            <div class="text-center">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <div>
                                                            <h6 class="mb-2">Categories</h6>
                                                            <p class="text-muted font-size-15">Project</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <div class="mt-4 mt-sm-0">
                                                            <h6 class="mb-2">Date</h6>
                                                            <p class="text-muted font-size-15">20 June, 2022</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <div class="mt-4 mt-sm-0">
                                                            <p class="text-muted mb-2">Post by</p>
                                                            <h5 class="font-size-15">Gilbert Smith</h5>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr>

                                            <div class="mt-4">
                                                <div class="text-muted font-size-14">
                                                    <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam enim ad minima veniam quis</p>

                                                    <p class="mb-4">Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt</p>

                                                    <blockquote class="p-4 border-light border rounded mb-4">
                                                        <div class="d-flex">
                                                            <div class="me-3">
                                                                <i class="bx bxs-quote-alt-left text-body font-size-24"></i>
                                                            </div>
                                                            <div>
                                                                <p class="mb-0"> At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium deleniti atque corrupti quos dolores et quas molestias excepturi sint quidem rerum facilis est</p>
                                                            </div>
                                                        </div>

                                                    </blockquote>

                                                    <p>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat. Sed ut perspiciatis unde omnis iste natus error sit</p>


                                                    <div class="mt-4">
                                                        <h5 class="mb-3">Title: </h5>

                                                        <div>
                                                            <div class="row">
                                                                <div class="col-lg-4 col-sm-6">
                                                                    <div>
                                                                        <ul class="ps-4">
                                                                            <li class="py-1">Donec sodales sagittis</li>
                                                                            <li class="py-1">Sed consequat leo eget</li>
                                                                            <li class="py-1">Aliquam lorem ante</li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-4 col-sm-6">
                                                                    <div>
                                                                        <ul class="ps-4">
                                                                            <li class="py-1">Aenean ligula eget</li>
                                                                            <li class="py-1">Cum sociis natoque</li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                                <hr>

                                                <div class="mt-5">
                                                    <h5 class="font-size-15"><i class="bx bx-message-dots text-muted align-middle me-1"></i> Comments :</h5>

                                                    <div>
                                                        <div class="d-flex py-3">
                                                            <div class="flex-shrink-0 me-3">
                                                                <div class="avatar-xs">
                                                                    <div class="avatar-title rounded-circle bg-light text-primary">
                                                                        <i class="bx bxs-user"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="flex-grow-1">
                                                                <h5 class="font-size-14 mb-1">Delores Williams <small class="text-muted float-end">1 hr Ago</small></h5>
                                                                <p class="text-muted">If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual</p>
                                                                <div>
                                                                    <a href="javascript: void(0);" class="text-success"><i class="mdi mdi-reply"></i> Reply</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex py-3 border-top">
                                                            <div class="flex-shrink-0 me-3">
                                                                <div class="avatar-xs">
                                                                    <img src="assets/images/users/avatar-2.jpg" alt="" class="img-fluid d-block rounded-circle">
                                                                </div>
                                                            </div>

                                                            <div class="flex-grow-1">
                                                                <h5 class="font-size-14 mb-1">Clarence Smith <small class="text-muted float-end">2 hrs Ago</small></h5>
                                                                <p class="text-muted">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet</p>
                                                                <div>
                                                                    <a href="javascript: void(0);" class="text-success"><i class="mdi mdi-reply"></i> Reply</a>
                                                                </div>

                                                                <div class="d-flex pt-3">
                                                                    <div class="flex-shrink-0 me-3">
                                                                        <div class="avatar-xs">
                                                                            <div class="avatar-title rounded-circle bg-light text-primary">
                                                                                <i class="bx bxs-user"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="flex-grow-1">
                                                                        <h5 class="font-size-14 mb-1">Silvia Martinez <small class="text-muted float-end">2 hrs Ago</small></h5>
                                                                        <p class="text-muted">To take a trivial example, which of us ever undertakes laborious physical exercise</p>
                                                                        <div>
                                                                            <a href="javascript: void(0);" class="text-success"><i class="mdi mdi-reply"></i> Reply</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="d-flex py-3 border-top">
                                                            <div class="flex-shrink-0 me-3">
                                                                <div class="avatar-xs">
                                                                    <div class="avatar-title rounded-circle bg-light text-primary">
                                                                        <i class="bx bxs-user"></i>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="flex-grow-1">
                                                                <h5 class="font-size-14 mb-1">Keith McCoy <small class="text-muted float-end">12 Aug</small></h5>
                                                                <p class="text-muted">Donec posuere vulputate arcu. phasellus accumsan cursus velit</p>
                                                                <div>
                                                                    <a href="javascript: void(0);" class="text-success"><i class="mdi mdi-reply"></i> Reply</a>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>

                                                <hr>
                                                <div class="mt-5">
                                                    <h5 class="font-size-16 mb-3">Leave a Reply:</h5>

                                                    <form>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label for="commentname-input" class="form-label">Name</label>
                                                                    <input type="text" class="form-control" id="commentname-input" placeholder="Enter name">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label for="commentemail-input" class="form-label">Email</label>
                                                                    <input type="email" class="form-control" id="commentemail-input" placeholder="Enter email">
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="mb-3">
                                                            <label for="commentmessage-input" class="form-label">Message</label>
                                                            <textarea class="form-control" id="commentmessage-input" placeholder="Your message..." rows="3"></textarea>
                                                        </div>

                                                        <div class="text-end">
                                                            <button type="submit" class="btn btn-primary w-sm">Submit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end card body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <!-- end col -->

                            <div class="col-lg-4 ">
                                <div class="row">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="search-box">
                                                <h5 class="mb-3">Search</h5>
                                                <div class="position-relative px-2">
                                                    <input type="text" class="form-control rounded bg-light border-light" placeholder="Search...">
                                                    <i class="mdi mdi-magnify search-icon"></i>
                                                </div>
                                            </div>
                                            <div class="mt-5">
                                                <h5 class="mb-3">Categories</h5>
                                                <ul class="list-unstyled fw-medium px-2">
                                                    <li><a href="javascript: void(0);" class="text-body pb-3 d-block border-bottom">Design<span class="badge bg-primary-subtle text-primary rounded-pill ms-1 float-end font-size-12">02</span></a></li>
                                                    <li><a href="javascript: void(0);" class="text-body py-3 d-block border-bottom">Development <span class="badge bg-primary-subtle text-primary rounded-pill float-end ms-1 font-size-12">04</span></a></li>
                                                    <li><a href="javascript: void(0);" class="text-body py-3 d-block border-bottom">Business<span class="badge bg-primary-subtle text-primary rounded-pill ms-1 float-end font-size-12">12</span></a></li>
                                                    <li><a href="javascript: void(0);" class="text-body py-3 d-block border-bottom">Project<span class="badge bg-primary-subtle text-primary rounded-pill ms-1 float-end font-size-12">08</span></a></li>
                                                    <li><a href="javascript: void(0);" class="text-body pt-3 pb-0 d-block">Travel<span class="badge bg-primary-subtle text-primary rounded-pill ms-1 float-end font-size-12">10</span></a></li>
                                                </ul>
                                            </div>
                                            <div class="mt-5">
                                                <h5 class="mb-3">Upcoming Post</h5>
                                                <div class="list-group list-group-flush">
                                                    <a href="javascript: void(0);" class="list-group-item text-muted pb-3 pt-0 px-2">
                                                        <div class="d-flex align-items-center">
                                                            <div class="flex-shrink-0 me-3">
                                                                <img src="assets/images/small/img-7.jpg" alt="" class="avatar-lg h-auto d-block rounded">
                                                            </div>
                                                            <div class="flex-grow-1 overflow-hidden">
                                                                <h5 class="font-size-13 text-truncate">Beautiful Day with Friends</h5>
                                                                <p class="mb-0 text-truncate">20 August, 2022 <span class="">/ 05:00 AM</span></p>
                                                            </div>
                                                            <div class="fs-1">
                                                                <i class="mdi mdi-calendar"></i>
                                                            </div>
                                                        </div>
                                                    </a>

                                                    <a href="javascript: void(0);" class="list-group-item text-muted py-3 px-2">
                                                        <div class="d-flex align-items-center">
                                                            <div class="flex-shrink-0 me-3">
                                                                <img src="assets/images/small/img-2.jpg" alt="" class="avatar-lg h-auto d-block rounded">
                                                            </div>
                                                            <div class="flex-grow-1 overflow-hidden">
                                                                <h5 class="font-size-13 text-truncate">Drawing a sketch</h5>
                                                                <p class="mb-0 text-truncate">20 August, 2022 <span class="">/ 05:05 AM</span></p>
                                                            </div>
                                                            <div class="fs-1">
                                                                <i class="mdi mdi-calendar"></i>
                                                            </div>
                                                        </div>
                                                    </a>

                                                    <a href="javascript: void(0);" class="list-group-item text-muted py-3 px-2">
                                                        <div class="d-flex align-items-center">
                                                            <div class="flex-shrink-0 me-3">
                                                                <img src="assets/images/small/img-6.jpg" alt="" class="avatar-lg h-auto d-block rounded">
                                                            </div>
                                                            <div class="flex-grow-1 overflow-hidden">
                                                                <h5 class="font-size-13 text-truncate">Project discussion with team</h5>
                                                                <p class="mb-0 text-truncate">20 August, 2022 <span class="">/ 05:10 PM</span></p>
                                                            </div>
                                                            <div class="fs-1">
                                                                <i class="mdi mdi-calendar"></i>
                                                            </div>
                                                        </div>
                                                    </a>

                                                    <a href="javascript: void(0);" class="list-group-item text-muted py-3 px-2">
                                                        <div class="d-flex align-items-center">
                                                            <div class="flex-shrink-0 me-3">
                                                                <img src="assets/images/small/img-1.jpg" alt="" class="avatar-lg h-auto d-block rounded">
                                                            </div>
                                                            <div class="flex-grow-1 overflow-hidden">
                                                                <h5 class="font-size-13 text-truncate">Coffee with friends</h5>
                                                                <p class="mb-0 text-truncate">20 August, 2022 <span class="">/ 05:30 PM</span></p>
                                                            </div>
                                                            <div class="fs-1">
                                                                <i class="mdi mdi-calendar"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>

                                            <div class="mt-5">
                                                <h5 class="mb-3">Popular Post</h5>
                                                <div class="list-group list-group-flush">
                                                    <a href="javascript: void(0);" class="list-group-item text-muted pb-3 pt-0 px-2">
                                                        <div class="d-flex align-items-center">
                                                            <div class="flex-shrink-0 me-3">
                                                                <img src="assets/images/small/img-3.jpg" alt="" class="avatar-xl h-auto d-block rounded">
                                                            </div>
                                                            <div class="flex-grow-1 overflow-hidden">
                                                                <h5 class="font-size-13 text-truncate">Beautiful Day with Friends</h5>
                                                                <p class="mb-0 text-truncate">10 Apr, 2022</p>
                                                            </div>
                                                        </div>
                                                    </a>

                                                    <a href="javascript: void(0);" class="list-group-item text-muted py-3 px-2">
                                                        <div class="d-flex align-items-center">
                                                            <div class="flex-shrink-0 me-3">
                                                                <img src="assets/images/small/img-4.jpg" alt="" class="avatar-xl h-auto d-block rounded">
                                                            </div>
                                                            <div class="flex-grow-1 overflow-hidden">
                                                                <h5 class="font-size-13 text-truncate">Drawing a sketch</h5>
                                                                <p class="mb-0 text-truncate">24 May, 2022</p>
                                                            </div>
                                                        </div>
                                                    </a>

                                                    <a href="javascript: void(0);" class="list-group-item text-muted py-3 px-2">
                                                        <div class="d-flex align-items-center">
                                                            <div class="flex-shrink-0 me-3">
                                                                <img src="assets/images/small/img-1.jpg" alt="" class="avatar-xl h-auto d-block rounded">
                                                            </div>
                                                            <div class="flex-grow-1 overflow-hidden">
                                                                <h5 class="font-size-13 text-truncate">Coffee with friends</h5>
                                                                <p class="mb-0 text-truncate">15 June, 2022</p>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>

                                            <div class="mt-5">
                                                <h5 class="mb-3">Tag Clouds</h5>
                                                <div class="px-2">
                                                    <a href="#" class="font-size-17"><span class="badge bg-primary-subtle text-primary">Design</span></a>
                                                    <a href="#" class="font-size-17"><span class="badge bg-primary-subtle text-primary">Development</span></a>
                                                    <a href="#" class="font-size-17"><span class="badge bg-primary-subtle text-primary">Wordpress</span></a>
                                                    <a href="#" class="font-size-17"><span class="badge bg-primary-subtle text-primary">HTML</span></a>
                                                    <a href="#" class="font-size-17"><span class="badge bg-primary-subtle text-primary">Project</span></a>
                                                    <a href="#" class="font-size-17"><span class="badge bg-primary-subtle text-primary">Business</span></a>
                                                    <a href="#" class="font-size-17"><span class="badge bg-primary-subtle text-primary">Travel</span></a>
                                                    <a href="#" class="font-size-17"><span class="badge bg-primary-subtle text-primary">Photography</span></a>
                                                </div>
                                            </div>

                                            <div class="mt-5">
                                                <h5 class="mb-3">Instagram Post</h5>
                                                <div class="gap-2 hstack flex-wrap px-2">
                                                    <img src="assets/images/small/img-3.jpg" alt="" class="avatar-xl rounded">
                                                    <img src="assets/images/small/img-1.jpg" alt="" class="avatar-xl rounded">
                                                    <img src="assets/images/small/img-2.jpg" alt="" class="avatar-xl rounded">
                                                    <img src="assets/images/small/img-4.jpg" alt="" class="avatar-xl rounded">
                                                    <img src="assets/images/small/img-5.jpg" alt="" class="avatar-xl rounded">
                                                    <img src="assets/images/small/img-6.jpg" alt="" class="avatar-xl rounded">
                                                </div>
                                            </div>

                                            <div class="mt-5">
                                                <h5 class="mb-3">Email Newsletter</h5>
                                                <div class="">
                                                    <div class="input-group mb-0 px-2">
                                                        <input type="text" class="form-control" placeholder="Enter Email">
                                                        <div class="input-group-append">
                                                            <span class="input-group-text"><i class="mdi mdi-send-outline"></i></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> <!-- end card -->
                                </div>
                            </div>

                        </div>
                        
                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->
                
                <?php include 'layouts/footer.php'; ?>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        
        <!-- Right Sidebar -->
            <?php include 'layouts/right-sidebar.php'; ?>
        <!-- /Right-bar -->

        <!-- JAVASCRIPT -->

        <?php include 'layouts/vendor-scripts.php'; ?>

        <!-- App js -->
        <script src="assets/js/app.js"></script>

    </body>
</html>
